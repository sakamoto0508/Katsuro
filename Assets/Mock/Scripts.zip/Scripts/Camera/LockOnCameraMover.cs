using Unity.Cinemachine;
using UnityEngine;

public class LockOnCameraMover
{
    public LockOnCameraMover(LockOnCamera lockOnCamera, Transform playerPosition
        , Transform enemyPosition, CinemachineCamera camera, CameraConfig config)
    {
        _lockOnCamera = lockOnCamera;
        _playerPosition = playerPosition;
        _enemyPosition = enemyPosition;
        _camera = camera;
        _cameraConfig = config;
    }

    private LockOnCamera _lockOnCamera;
    private Transform _playerPosition;
    private Transform _enemyPosition;
    private CinemachineCamera _camera;
    private CameraConfig _cameraConfig;

    public void LateUpdate()
    {
        if (_lockOnCamera.IsLockOn == false) return;
        if (_lockOnCamera.IsLockOn) UpdateLockOnCamera();
    }

    private void UpdateLockOnCamera()
    {
        //�G�̕����x�N�g�������߂�B���\�b�h���g��Ȃ��̂�y������0�ɂ��Ă��邽�߁B
        Vector3 toEnemy = _enemyPosition.position - _playerPosition.position;
        toEnemy.y = 0;
       
        Vector3 forward = toEnemy.normalized;
        //�v���C���[�̌��ɃJ�������ړ�������B
        Vector3 desiredPos = _playerPosition.position - forward
            * _cameraConfig.CameraDistance + Vector3.up * _cameraConfig.CameraHeight;
        // �X���[�Y�Ɉړ�������B
        // If CinemachineBrain has been disabled for manual control, move the main camera transform directly.
        Transform camTransfrom = null;
        var mainCam = Camera.main;
        var brain = mainCam != null ? mainCam.GetComponent<Unity.Cinemachine.CinemachineBrain>() : null;
        if (brain != null && !brain.enabled && mainCam != null)
        {
            camTransfrom = mainCam.transform;
        }
        else if (_camera != null)
        {
            camTransfrom = _camera.transform;
        }

        if (camTransfrom != null)
        {
            camTransfrom.position = Vector3.Lerp(camTransfrom.position, desiredPos
                , Time.deltaTime * _cameraConfig.PositionSmooth);
        }
        //�J������G�Ɍ�����B
        Vector3 lookDir = (_enemyPosition.position + Vector3.up * _cameraConfig.LookAtHeight)
            - camTransfrom.position;
        //�X���[�Y�ɉ�]������B
        Quaternion targetRot = Quaternion.LookRotation(lookDir.normalized);
        if (camTransfrom != null)
        {
            camTransfrom.rotation = Quaternion.Slerp(camTransfrom.rotation, targetRot
                , Time.deltaTime * _cameraConfig.RotationSmooth);
        }
    }
}
